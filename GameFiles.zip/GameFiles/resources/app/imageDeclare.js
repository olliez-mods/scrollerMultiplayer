backroundImg = new Image;
backroundImg.src = "backround.png";

playerImg = new Image;
playerImg.src = "playerSprites/0.png";

barrierImg = new Image;
barrierImg.src = "objectSprites/barrier.png"

youSignImg = new Image;
youSignImg.src = "youSign.png"
